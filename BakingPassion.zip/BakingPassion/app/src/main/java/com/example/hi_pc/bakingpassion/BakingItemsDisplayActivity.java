package com.example.hi_pc.bakingpassion;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BakingItemsDisplayActivity extends AppCompatActivity {
    public static String POSITION = "position";
    RecyclerView recyclerView;
    Snackbar snackbar;
    GridLayoutManager gridLayoutManager;
    int scrollPosition = 0;
    ProgressDialog progressDialog;
    LinearLayout linearLayout;
    Call<List<BakingPojo>> call;

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (checkOnline()) {
            if (call.isExecuted() && !(progressDialog.isShowing()))
                scrollPosition = gridLayoutManager.findFirstVisibleItemPosition();
            outState.putInt(POSITION, scrollPosition);
            super.onSaveInstanceState(outState);
        }
    }

    private int numberOfColumns() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int widthDivider = 600;
        int width = displayMetrics.widthPixels;
        int nColumns = width / widthDivider;
        if (nColumns < 2) return 1;
        return nColumns;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (progressDialog.isShowing())
            progressDialog.dismiss();
    }

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_baking_items_display);
        linearLayout = (LinearLayout) findViewById(R.id.snackbar_view);
        recyclerView = (RecyclerView) findViewById(R.id.baking_recycler);
        if (checkOnline()) {
            if (snackbar != null)
                snackbar.dismiss();
            progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Loading Data,Please Wait");
            progressDialog.show();
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(BakingApi.BAKING_BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
            BakingApi bakingApi = retrofit.create(BakingApi.class);
            call = bakingApi.getItemDetails();
            call.enqueue(new Callback<List<BakingPojo>>() {
                @Override
                public void onResponse(Call<List<BakingPojo>> call, Response<List<BakingPojo>> response) {
                    List<BakingPojo> items = response.body();
                    if (savedInstanceState != null)
                        scrollPosition = savedInstanceState.getInt(POSITION);
                    gridLayoutManager = new GridLayoutManager(BakingItemsDisplayActivity.this, numberOfColumns());
                    MyBakerAdapter bakerAdapter = new MyBakerAdapter(BakingItemsDisplayActivity.this, items);
                    recyclerView.setLayoutManager(gridLayoutManager);
                    recyclerView.setAdapter(bakerAdapter);
                    recyclerView.scrollToPosition(scrollPosition);
                    progressDialog.dismiss();
                }

                @Override
                public void onFailure(Call<List<BakingPojo>> call, Throwable t) {
                    Log.i("fail", t.getMessage());
                }
            });
        } else {
            setSnackBar();
        }

    }

    private void retry() {
        Intent intent = new Intent(BakingItemsDisplayActivity.this, BakingItemsDisplayActivity.class);
        finish();
        startActivity(intent);
    }

    private void setSnackBar() {
        snackbar = Snackbar.make(linearLayout, getResources().getString(R.string.NoInternet), Snackbar.LENGTH_INDEFINITE)
                .setAction(getResources().getString(R.string.RETRY), new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        retry();
                    }
                });
        snackbar.setActionTextColor(Color.RED);
        View view = snackbar.getView();
        TextView tv = (TextView) view.findViewById(android.support.design.R.id.snackbar_text);
        tv.setTextColor(Color.YELLOW);
        snackbar.show();
    }

    private boolean checkOnline() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null)
            return true;
        else
            return false;
    }
}
