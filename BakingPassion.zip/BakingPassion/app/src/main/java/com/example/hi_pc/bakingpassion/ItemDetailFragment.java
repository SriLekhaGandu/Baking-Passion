package com.example.hi_pc.bakingpassion;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.upstream.BandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.squareup.picasso.Picasso;

import java.util.List;
import java.util.Objects;

/**
 * A fragment representing a single Item detail screen.
 * This fragment is either contained in a {@link ItemListActivity}
 * in two-pane mode (on tablets) or a {@link ItemDetailActivity}
 * on handsets.
 */
public class ItemDetailFragment extends Fragment {
    public static final String POSITION = "position";
    public static final String PLAY_BACK = "play_back";
    SimpleExoPlayerView simpleExoPlayerView = null;
    SimpleExoPlayer simpleExoPlayer;
    BakingPojo bakingPojo;
    ImageView imageView;
    CardView cardView;
    List<IngredientData> ingredientData;
    List<StepsData> stepsData;
    Button prev, next;
    TextView mview, qview, view;
    int pos;

    public ItemDetailFragment() {
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (simpleExoPlayer != null) {
            long position = simpleExoPlayer.getCurrentPosition();
            boolean playBack = simpleExoPlayer.getPlayWhenReady();
            outState.putLong(POSITION, position);
            outState.putBoolean(PLAY_BACK, playBack);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            if (simpleExoPlayer != null) {
                ViewGroup.LayoutParams layoutParams = simpleExoPlayerView.getLayoutParams();
                layoutParams.width = layoutParams.MATCH_PARENT;
                layoutParams.height = layoutParams.MATCH_PARENT;
                simpleExoPlayerView.setLayoutParams(layoutParams);
            }
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments().containsKey(getResources().getString(R.string.ingredients))) {
            bakingPojo = getArguments().getParcelable(getResources().getString(R.string.ingredients));
            ingredientData = bakingPojo.getIngredients();

        }
        if (getArguments().containsKey(getResources().getString(R.string.steps))) {
            bakingPojo = getArguments().getParcelable(getResources().getString(R.string.steps));
            stepsData = bakingPojo.getSteps();
            pos = getArguments().getInt("position");
        }
    }

    @Override
    public void onDestroy() {
        if (simpleExoPlayer != null)
            simpleExoPlayer.release();
        super.onDestroy();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onPause() {
        if (simpleExoPlayer != null)
            simpleExoPlayer.release();
        super.onPause();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            Intent intent = new Intent(getContext(), ItemListActivity.class);
            intent.putExtra(getResources().getString(R.string.Data), bakingPojo);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (simpleExoPlayer != null) {
            if (simpleExoPlayer.getCurrentPosition() != simpleExoPlayer.getDuration())
                simpleExoPlayer.release();
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onViewCreated(View view, @Nullable final Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,
                             final Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.item_detail, container, false);
        prev = (Button) rootView.findViewById(R.id.prev);
        next = (Button) rootView.findViewById(R.id.next);
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (pos > 0) {
                    pos--;
                    playVideo();
                } else
                    Toast.makeText(getContext(), "This is first video", Toast.LENGTH_SHORT).show();
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (pos < bakingPojo.getSteps().size() - 1) {
                    pos++;
                    playVideo();
                } else {
                    Toast.makeText(getContext(), "This is last video", Toast.LENGTH_SHORT).show();
                }
            }
        });
        cardView = (CardView) rootView.findViewById(R.id.my_card_view);
        view = rootView.findViewById(R.id.ing_text_view);
        qview = rootView.findViewById(R.id.name);
        mview = rootView.findViewById(R.id.measure_text_view);
        if (getArguments().containsKey(getResources().getString(R.string.ingredients))) {
            view.setVisibility(View.VISIBLE);
            qview.setVisibility(View.VISIBLE);
            qview.setText(bakingPojo.getName());
            for (int p = 0; p < bakingPojo.getIngredients().size(); p++) {
                view.append("Ingredient:" + bakingPojo.getIngredients().get(p).getIngredientName() + "\n");
                view.append("Quantity:" + bakingPojo.getIngredients().get(p).getQuantity() + "\n");
                view.append("Measure:" + bakingPojo.getIngredients().get(p).getMeasure() + "\n\n\n");
            }
        }
        if (getArguments().containsKey(getResources().getString(R.string.steps))) {
            {
                if (getArguments().containsKey("twopane")) {
                    if (getArguments().getBoolean("twopane") == false) {
                        prev.setVisibility(View.VISIBLE);
                        next.setVisibility(View.VISIBLE);
                    }
                }
                simpleExoPlayerView = (SimpleExoPlayerView) rootView.findViewById(R.id.exoplayer_view);
                imageView = (ImageView) rootView.findViewById(R.id.image_view);
                BandwidthMeter bandwidthMeter = new DefaultBandwidthMeter();
                TrackSelector trackSelector = new DefaultTrackSelector(new AdaptiveTrackSelection.Factory(bandwidthMeter));
                simpleExoPlayer = ExoPlayerFactory.newSimpleInstance(rootView.getContext(), trackSelector);
                playVideo();
            }
        }
        if (savedInstanceState != null) {
            if (simpleExoPlayer != null) {
                simpleExoPlayer.setPlayWhenReady(savedInstanceState.getBoolean(PLAY_BACK));
                simpleExoPlayer.seekTo(savedInstanceState.getLong(POSITION));
            }
        }
        return rootView;
    }

    public void playVideo() {
        view.setVisibility(View.VISIBLE);
        qview.setVisibility(View.VISIBLE);
        qview.setText("Description:");
        view.setText(bakingPojo.getSteps().get(pos).getDescription());
        BakingPojo bakingPojo = getArguments().getParcelable(getResources().getString(R.string.steps));
        String videoURL = bakingPojo.getSteps().get(pos).getVideoURL();
        String thumbnailURL = bakingPojo.getSteps().get(pos).getThumbnailURL();
        if (Objects.equals(videoURL, "")) {
            if (thumbnailURL.endsWith("mp4")) {
                videoURL = bakingPojo.getSteps().get(pos).getThumbnailURL();
            }
        }
        if (!Objects.equals(videoURL, "")) {
            simpleExoPlayerView.setVisibility(View.VISIBLE);
            mview.setVisibility(View.GONE);
            imageView.setVisibility(View.GONE);
            try {
                Uri videoURI = Uri.parse(videoURL);
                DefaultHttpDataSourceFactory dataSourceFactory = new DefaultHttpDataSourceFactory("exoplayer_video");
                ExtractorsFactory extractorsFactory = new DefaultExtractorsFactory();
                MediaSource mediaSource = new ExtractorMediaSource(videoURI, dataSourceFactory, extractorsFactory, null, null);
                simpleExoPlayerView.setPlayer(simpleExoPlayer);
                simpleExoPlayer.prepare(mediaSource);
                simpleExoPlayer.setPlayWhenReady(false);

            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            if (thumbnailURL.isEmpty()) {
                simpleExoPlayerView.setVisibility(View.GONE);
                view.setVisibility(View.VISIBLE);
                qview.setVisibility(View.VISIBLE);
                qview.append("\n\nNo Image or Video Found For this Step");
                view.setVisibility(View.VISIBLE);
            } else {
                simpleExoPlayerView.setVisibility(View.GONE);
                imageView.setVisibility(View.VISIBLE);
                Picasso.with(getContext()).load(thumbnailURL).placeholder(R.mipmap.ic_launcher).into(imageView);
            }
        }
    }
}

