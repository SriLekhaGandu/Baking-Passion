package com.example.hi_pc.bakingpassion;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by HI-PC on 04-06-2018.
 */

public class BakingPojo implements Parcelable {
    public static final Creator<BakingPojo> CREATOR = new Creator<BakingPojo>() {
        @Override
        public BakingPojo createFromParcel(Parcel in) {
            return new BakingPojo(in);
        }

        @Override
        public BakingPojo[] newArray(int size) {
            return new BakingPojo[size];
        }
    };
    @SerializedName("id")
    int id;
    @SerializedName("name")
    String name;
    @SerializedName("ingredients")
    List<IngredientData> ingredients;
    @SerializedName("steps")
    List<StepsData> steps;
    @SerializedName("servings")
    int servings;
    @SerializedName("image")
    String image;

    protected BakingPojo(Parcel in) {
        id = in.readInt();
        name = in.readString();
        ingredients = in.createTypedArrayList(IngredientData.CREATOR);
        steps = in.createTypedArrayList(StepsData.CREATOR);
        servings = in.readInt();
        image = in.readString();
    }

    public BakingPojo(int id, String name, List<IngredientData> ingredients, List<StepsData> steps, int servings, String image) {
        this.id = id;
        this.name = name;
        this.ingredients = ingredients;
        this.steps = steps;
        this.servings = servings;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<IngredientData> getIngredients() {
        return ingredients;
    }

    public void setIngredients(List<IngredientData> ingredients) {
        this.ingredients = ingredients;
    }

    public List<StepsData> getSteps() {
        return steps;
    }

    public void setSteps(List<StepsData> steps) {
        this.steps = steps;
    }

    public int getServings() {
        return servings;
    }

    public void setServings(int servings) {
        this.servings = servings;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(getId());
        parcel.writeString(getName());
        parcel.writeTypedList(getIngredients());
        parcel.writeTypedList(getSteps());
        parcel.writeInt(getServings());
        parcel.writeString(getImage());
    }
}
