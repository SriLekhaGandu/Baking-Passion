package com.example.hi_pc.bakingpassion;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

import static com.example.hi_pc.bakingpassion.R.string.ingredients;

/**
 * An activity representing a single Item detail screen. This
 * activity is only used on narrow width devices. On tablet-size devices,
 * item details are presented side-by-side with a list of items
 * in a {@link ItemListActivity}.
 */
public class ItemDetailActivity extends AppCompatActivity {
    public static final String Title = "title";
    BakingPojo baking;
    Bundle arguments = null;
    Button prev, next;

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        String title = String.valueOf(getTitle());
        outState.putString(Title, title);
        super.onSaveInstanceState(outState);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);
        if (savedInstanceState == null) {
            Bundle bundle = getIntent().getExtras();
            if (bundle != null) {
                if (bundle.containsKey(getResources().getString(R.string.ingredients))) {
                    baking = getIntent().getParcelableExtra(getResources().getString(R.string.ingredients));
                    arguments = new Bundle();
                    arguments.putParcelable(getResources().getString(ingredients), baking);
                    setTitle("Ingredients");
                }
                if (bundle.containsKey(getResources().getString(R.string.steps))) {
                    baking = getIntent().getParcelableExtra(getResources().getString(R.string.steps));
                    int positon = getIntent().getIntExtra("position", 0);
                    arguments = new Bundle();
                    arguments.putParcelable(getResources().getString(R.string.steps), baking);
                    arguments.putInt("position", positon);
                    arguments.putBoolean("twopane", false);
                    setTitle("Video Receipe");
                }
                ItemDetailFragment fragment = new ItemDetailFragment();
                fragment.setArguments(arguments);
                getSupportFragmentManager().beginTransaction()
                        .add(R.id.item_detail_container, fragment)
                        .commit();
            }
        } else {
            setTitle(savedInstanceState.getString(Title));
        }
        Intent intent = new Intent(getApplicationContext(), ItemListActivity.class);
        intent.putExtra(getResources().getString(R.string.Data), baking);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            Intent intent = new Intent(this, ItemListActivity.class);
            intent.putExtra(getResources().getString(R.string.Data), baking);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
