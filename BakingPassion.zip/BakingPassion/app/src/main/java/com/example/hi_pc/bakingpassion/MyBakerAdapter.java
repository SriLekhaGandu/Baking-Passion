package com.example.hi_pc.bakingpassion;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MyBakerAdapter extends RecyclerView.Adapter<MyBakerAdapter.MyBakerHolder> {
    Context context;
    ArrayList<Parcelable> parcelables = new ArrayList<Parcelable>();
    List<BakingPojo> bakingItems;

    public MyBakerAdapter(Context baking_items_display_activity, List<BakingPojo> items) {
        this.bakingItems = items;
        this.context = baking_items_display_activity;
    }

    @Override
    public MyBakerHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        int id = R.layout.baking_items;
        Context c = parent.getContext();
        LayoutInflater layoutInflater = LayoutInflater.from(c);
        View v = layoutInflater.inflate(id, parent, false);
        MyBakerHolder myBakerHolder = new MyBakerHolder(v);
        return myBakerHolder;
    }

    @Override
    public void onBindViewHolder(MyBakerHolder holder, int position) {
        holder.itemTextView.setText(bakingItems.get(position).getName());
        holder.servingsView.setText("Servings:" + bakingItems.get(position).getServings());
    }

    @Override
    public int getItemCount() {
        return bakingItems.size();
    }

    public class MyBakerHolder extends RecyclerView.ViewHolder {
        TextView itemTextView, servingsView;
        ImageView imageView;

        public MyBakerHolder(final View itemView) {
            super(itemView);
            itemTextView = (TextView) itemView.findViewById(R.id.items_view);
            servingsView = (TextView) itemView.findViewById(R.id.items_servings);
            itemTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(context, ItemListActivity.class);
                    intent.putExtra(itemView.getResources().getString(R.string.Data), bakingItems.get(getAdapterPosition()));
                    itemView.getContext().startActivity(intent);
                }
            });
        }
    }
}
