package com.example.hi_pc.bakingpassion;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

/**
 * Created by HI-PC on 04-06-2018.
 */

public interface BakingApi {
    public String BAKING_BASE_URL = "https://d17h27t6h515a5.cloudfront.net/topher/2017/May/59121517_baking/";

    @GET("baking.json")
    Call<List<BakingPojo>> getItemDetails();

}
