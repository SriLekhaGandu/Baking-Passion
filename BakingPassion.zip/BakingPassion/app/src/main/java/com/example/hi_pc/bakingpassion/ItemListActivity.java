package com.example.hi_pc.bakingpassion;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class ItemListActivity extends AppCompatActivity {
    static String ingredient = "";
    BakingPojo bakingPojo;
    int scroll = 0;
    private boolean mTwoPane;

    public static String getWidgetDetails() {
        return ingredient;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = new MenuInflater(this);
        menuInflater.inflate(R.menu.set_widget, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        String name, quantity, measure, app;
        if (item.getItemId() == R.id.add_widget) {
            ingredient = "";
            app = bakingPojo.getName();
            Toast.makeText(getApplicationContext(), "Added to widget", Toast.LENGTH_SHORT).show();
            for (int i = 0; i < bakingPojo.getIngredients().size(); i++) {
                name = bakingPojo.getIngredients().get(i).getIngredientName();
                quantity = "" + bakingPojo.getIngredients().get(i).getQuantity();
                measure = bakingPojo.getIngredients().get(i).getMeasure();
                ingredient = ingredient + "\t" + name + "\t" + quantity + measure + "\n";
            }
            ingredient = app + "\n" + ingredient;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_list);
        Toast.makeText(getApplicationContext(), "You can add widget in menu", Toast.LENGTH_SHORT).show();
        Intent intent = getIntent();
        bakingPojo = intent.getParcelableExtra(getResources().getString(R.string.Data));
        setTitle(bakingPojo.getName());
        FrameLayout frameLayout = (FrameLayout) findViewById(R.id.item_detail_container);
        if (findViewById(R.id.item_detail_container) != null) {
            mTwoPane = true;
        }
        View recyclerView = findViewById(R.id.item_list);
        assert recyclerView != null;
        setupRecyclerView((RecyclerView) recyclerView);
    }

    private void setupRecyclerView(@NonNull RecyclerView recyclerView) {
        recyclerView.setAdapter(new SimpleItemRecyclerViewAdapter(this, bakingPojo, bakingPojo.getIngredients(), bakingPojo.getSteps(), mTwoPane));
    }

    public static class SimpleItemRecyclerViewAdapter
            extends RecyclerView.Adapter<SimpleItemRecyclerViewAdapter.ViewHolder> {
        private final List<IngredientData> ingredientData;
        private final ItemListActivity mParentActivity;
        private final List<StepsData> stepsData;
        private final BakingPojo baking;
        private final boolean mTwoPane;

        SimpleItemRecyclerViewAdapter(ItemListActivity parent, BakingPojo bakingPojo,
                                      List<IngredientData> ingredientData, List<StepsData> items,
                                      boolean twoPane) {
            this.ingredientData = ingredientData;
            this.stepsData = items;
            this.baking = bakingPojo;
            this.mParentActivity = parent;
            this.mTwoPane = twoPane;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_list_content, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final ViewHolder holder, final int position) {
            if (position == 0) {
                holder.stepView.setText("Receipe Ingredients");
                holder.cardView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (mTwoPane) {
                            Intent intent = new Intent(view.getContext(), ItemDetailActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putParcelable(view.getResources().getString(R.string.ingredients), baking);
                            ItemDetailFragment fragment = new ItemDetailFragment();
                            fragment.setArguments(bundle);
                            mParentActivity.getSupportFragmentManager().beginTransaction()
                                    .replace(R.id.item_detail_container, fragment)
                                    .commit();

                        } else {
                            Context c = view.getContext();
                            Intent intent = new Intent(c, ItemDetailActivity.class);
                            intent.putExtra(view.getResources().getString(R.string.ingredients), baking);
                            c.startActivity(intent);
                        }
                    }
                });
            } else {
                holder.stepView.setText(stepsData.get(position - 1).getShortDescription());
                holder.cardView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (mTwoPane) {
                            Intent intent = new Intent(view.getContext(), ItemDetailActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putParcelable(view.getResources().getString(R.string.steps), baking);
                            bundle.putInt("position", position - 1);
                            ItemDetailFragment fragment = new ItemDetailFragment();
                            fragment.setArguments(bundle);
                            mParentActivity.getSupportFragmentManager().beginTransaction()
                                    .replace(R.id.item_detail_container, fragment)
                                    .commit();
                        } else {
                            Context c = view.getContext();
                            Intent intent = new Intent(c, ItemDetailActivity.class);
                            intent.putExtra(view.getResources().getString(R.string.steps), baking);
                            intent.putExtra("position", position - 1);
                            c.startActivity(intent);
                        }
                    }
                });
            }
        }

        @Override
        public int getItemCount() {
            return stepsData.size() + 1;
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView stepView;
            CardView cardView;

            ViewHolder(View view) {
                super(view);
                cardView = (CardView) view.findViewById(R.id.list_card_view);
                stepView = view.findViewById(R.id.id_text);
            }
        }
    }
}